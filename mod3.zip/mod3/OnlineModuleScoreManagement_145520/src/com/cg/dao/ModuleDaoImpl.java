package com.cg.dao;

import java.sql.Connection;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.cg.dto.AssessmentScoreBean;
import com.cg.dto.TraineeBean;
import com.cg.exceptions.ModuleException;


public class ModuleDaoImpl implements ModuleDao{
	Connection conn;

	public ModuleDaoImpl() {
		
	}

	@Override
	public List<TraineeBean> getAllConsumers() throws ModuleException {
		List<TraineeBean> tlist = new ArrayList<TraineeBean>();
		conn=DBUtil.getConnection();
		String sql="SELECT trainee_id,trainee_name FROM trainees";
		try {
			PreparedStatement pst=conn.prepareStatement(sql);
			ResultSet rst=pst.executeQuery();
			while(rst.next())
			{
				TraineeBean trainee= new TraineeBean ();
				trainee.setTraineeId(rst.getInt("trainee_id"));
				trainee.setTraineeName(rst.getString("trainee_name"));
				tlist.add(trainee);
				}
		} catch (SQLException e) {
			throw new ModuleException("Problem in fetching trainee list");
			
		}
		
		return tlist;
	}

	@Override
	public long insertAssessment(AssessmentScoreBean assg)
			throws ModuleException {
		String sql="INSERT INTO AssessmentScore VALUES(?,?,?,?,?,?,?)";
		conn=DBUtil.getConnection();
		int ct=0;
		try {
			conn=DBUtil.getConnection();
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1, assg.getTraineeId());
			pst.setString(2,assg.getModuleName());
			pst.setInt(3,assg.getMpt());
			pst.setInt(4,assg.getMtt());
			pst.setInt(5,assg.getAssMarks());
			pst.setDouble(6,assg.getTotalNumber());
			pst.setDouble(7,assg.getGrade());
			ct=pst.executeUpdate();
						
		} catch (SQLException e) 
		{
			throw new ModuleException("Problem in inserting data");
			
		}
		
		return assg.getTraineeId();


	}

	@Override
	public int count(int id, String Name) throws ModuleException {
		int r=0;
		String sql="SELECT * FROM  AssessmentScore where trainee_id=? AND module_name=?";
		conn=DBUtil.getConnection();
		try {
			PreparedStatement pst=conn.prepareStatement(sql);
			
			pst.setInt(1,id);
			pst.setString(2,Name);
			ResultSet rst=pst.executeQuery();
			if(rst.next())
			{
				
				r=1;
				System.out.println("exist"+r);
			}
			else
			{
				r=0;
				System.out.println(r);
			}
		} catch (SQLException e) {
			throw new ModuleException(e.getMessage());
		}
		
		return r;
	}





	}





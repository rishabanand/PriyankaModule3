
public class Divide {

	public static void divide(float num1,float num2)
	{
		try
		{
			float res=num1/num2;
			System.out.println("result :"+res);
		}catch(RuntimeException e)
		{
			System.out.println("in catch");
		}finally{
			System.out.println("in final block");
		}
	}
	public static void main(String[] args)
	{
		divide(23,0);
	}
}

package com.cg.date;

public class l1 {

	
		
			public static void main(String[] args) {
				char f=24;
				char ch=(char) f;
				System.out.println(ch);
			}

		}

	



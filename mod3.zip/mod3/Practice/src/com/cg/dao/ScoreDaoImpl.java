package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.dto.Trainees;
import com.cg.exception.ScoreException;

public class ScoreDaoImpl implements IScoreDao{
	Connection conn;


	public ScoreDaoImpl() {
		
	}

	@Override
	public List<Trainees> getAllTrainees() throws ScoreException {
		List<Trainees> tlist = new ArrayList<Trainees>();
		conn=DBUtil.getConnection();
		String sql="SELECT trainee_id,trainee_name FROM trainees";
		try {
			PreparedStatement pst=conn.prepareStatement(sql);
			ResultSet rst=pst.executeQuery();
			while(rst.next())
			{
				
			Trainees trainee= new Trainees();
				trainee.setTraineeId(rst.getInt("trainee_id"));
				trainee.setTraineeName(rst.getString("trainee_name"));
				tlist.add(trainee);
				System.out.println("in trainee");
				}
		} catch (SQLException e) {
			throw new ScoreException("Problem in fetching trainee list");
			
		
	}
return tlist;
}
}

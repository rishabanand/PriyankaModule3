package com.cg.service;

import com.cg.dao.BillDao;
import com.cg.dao.BillDaoImpl;
import com.cg.dto.BillDetails;
import com.cg.dto.Customer;
import com.cg.exception.BillException;

public class ServiceBillImpl implements ServiceBill{
	BillDao bao=new BillDaoImpl();
	
     @Override
	public int addBillDetails(BillDetails bill) throws BillException {
		
		return bao.addBillDetails(bill);
	}

	@Override
	public Customer getCustomerDetails(int cid) throws BillException {
		
		return bao.getCustomerDetails(cid);
	}

}

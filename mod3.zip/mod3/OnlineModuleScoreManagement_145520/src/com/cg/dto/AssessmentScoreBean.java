package com.cg.dto;

public class AssessmentScoreBean {
	private int traineeId;
	private int grade;
	
	public int getGrade() {
		return grade;
	}



	public void setGrade(int grade) {
		this.grade = grade;
	}



	public String getModuleName() {
		return moduleName;
	}



	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}



	public int getMpt() {
		return mpt;
	}



	public void setMpt(int mpt) {
		this.mpt = mpt;
	}



	public int getMtt() {
		return mtt;
	}



	public void setMtt(int mtt) {
		this.mtt = mtt;
	}



	public int getAssMarks() {
		return assMarks;
	}



	public void setAssMarks(int assMarks) {
		this.assMarks = assMarks;
	}


   public int getTraineeId() {
		return traineeId;
	}



	public void setTraineeId(int traineeId) {
		this.traineeId = traineeId;
	}



	private String moduleName;
	private int mpt;
	private int mtt;
	private int assMarks;
	private int totalNumber;
	
	

	public AssessmentScoreBean(int totalNumber) {
		super();
		this.totalNumber = totalNumber;
	}



	public int getTotalNumber() {
		return totalNumber;
	}



	public void setTotalNumber(int totalNumber) {
		this.totalNumber = totalNumber;
	}



	public AssessmentScoreBean() {
		// TODO Auto-generated constructor stub
	}

}

package com.cg.service;

import java.util.List;

import com.cg.dao.IScoreDao;
import com.cg.dao.ScoreDaoImpl;
import com.cg.dto.Trainees;
import com.cg.exception.ScoreException;

public class ServiceImpl implements IService{
	IScoreDao dao=new ScoreDaoImpl();

	public ServiceImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public List<Trainees> getAllTrainees() throws ScoreException {
		
		return dao.getAllTrainees();
	}

}

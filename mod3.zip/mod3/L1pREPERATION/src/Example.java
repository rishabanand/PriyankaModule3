import java.util.Set;
import java.util.TreeSet;
import java.util.Iterator;



public class Example {

	public static void main(String[] args) 
		

	{
		Set set=new TreeSet();
		set.add("1");
		set.add("2");
		java.util.Iterator it= set.iterator();
		while(it.hasNext())
			System.out.println(it.next() +" ");
	}

}

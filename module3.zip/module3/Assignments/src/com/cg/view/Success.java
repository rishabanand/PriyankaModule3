package com.cg.view;

import java.io.IOException;

import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.cg.dto.User;


@WebServlet("/success")
public class Success extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public Success() {
        super();
       
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	User user=(User) request.getAttribute("use");
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		out.print("<h1>Registration Done</h1>");
		out.print("<h2> Registered With below Details</h2>");
		out.print("<h3>FirstName:"+user.getFirstName()+" </h3>");
		out.print("<h3>LastName:"+user.getLastName()+" </h3>");
	out.print("<h3>Password:"+user.getPassword()+" </h3>");
		out.print("<h3>Gender:"+user.getGender()+" </h3>");
		out.print("<h3>Skills:"+user.getSkill()+" </h3>");
		out.print("<h3>City:"+user.getCity()+" </h3>");
		out.print("<a href='index.html'>Home</a>");
	}

}

package com.cg.dao;

import com.cg.dto.User;
import com.cg.exception.UserException;




public interface UserDao {
	int insertEmp(User user) throws UserException;

}

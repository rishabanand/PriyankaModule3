package com.cg.demos;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/register" )
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public RegisterServlet() {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String ename=request.getParameter("ename");
		String ageStr=request.getParameter("age");
		int age=Integer.parseInt(ageStr);
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		if(age>=18 && age<=60)
		{
			//response.setStatus(HttpServletResponse.SC_MOVED_TEMPORARILY);
			//response.setHeader("Location","http://talent.capgemini.com");
			//response.sendRedirect("http://talent.capgemini.com");
			//out.print("<h1> Welcome" +ename+ "</h1>");
			out.print("You will be redirected in 5 secs..");
			response.setHeader("Refresh","5;URL=https://talent.capgemini.com");
		}else{
			//out.print("<h1 style='color:red'> InValid Age For an Employee</h1>");
			response.sendError(HttpServletResponse.SC_UNAUTHORIZED);
		}
	}

}

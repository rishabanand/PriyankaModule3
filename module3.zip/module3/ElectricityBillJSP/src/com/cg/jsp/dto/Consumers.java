package com.cg.jsp.dto;

public class Consumers {
	private int consumerNo;
	private String consumerName;
	private String address;


	public Consumers(int consumerNo, String consumerName, String address) {
		super();
		this.consumerNo = consumerNo;
		this.consumerName = consumerName;
		this.address = address;
	}


	public int getConsumerNo() {
		return consumerNo;
	}


	public void setConsumerNo(int consumerNo) {
		this.consumerNo = consumerNo;
	}


	public String getConsumerName() {
		return consumerName;
	}


	public void setConsumerName(String consumerName) {
		this.consumerName = consumerName;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public Consumers() {
		
	}

}

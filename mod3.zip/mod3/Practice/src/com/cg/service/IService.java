package com.cg.service;

import java.util.List;

import com.cg.dto.Trainees;
import com.cg.exception.ScoreException;

public interface IService {
	List<Trainees> getAllTrainees() throws ScoreException;

}

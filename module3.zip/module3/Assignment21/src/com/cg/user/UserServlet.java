package com.cg.user;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/user")
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public UserServlet() {
        super();
       
    }

	 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String usname=request.getParameter("uname");
		String passwrd=request.getParameter("pwd");
		 if (validate(usname,passwrd))
		{
			response.sendRedirect("success");
		}else
		{
			response.sendRedirect("failure");
		}
		
 }
	private boolean validate(String username,String password)
	{
		if(username.equals("admin") && password.equals("admin123"))
		{
		  return true;
		}
		else
		{
			return false;
			
		}
		
	}
	
	
	}
	
	



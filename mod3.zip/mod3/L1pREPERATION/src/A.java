
public class A {

	String name;

	A()
	{
		
	}
	public A(String name) {
		this.name=name;
	}
	class B extends A
	{
		B()
		{
			
		}
		B(String name,int number)
		{
			super(name);
			this(name);
			
			
			
		}
	}
	
}

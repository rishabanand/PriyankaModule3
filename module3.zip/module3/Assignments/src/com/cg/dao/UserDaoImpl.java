package com.cg.dao;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.cg.dto.User;
import com.cg.exception.UserException;

import java.sql.Connection;

public class UserDaoImpl implements UserDao {
	Connection conn;

	
	@Override
	public int insertEmp(User user) throws UserException {
		String sql="INSERT INTO RegisteredUsers VALUES(?,?,?,?,?,?)";
		int ct=0;
		conn=DBUtil.getConnection();
		try {
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1, user.getFirstName());
			pst.setString(2,user.getLastName());
		    pst.setString(3,user.getPassword());
			pst.setString(4,user.getGender());
			pst.setString(5,user.getSkill());
			pst.setString(6,user.getCity());
			ct=pst.executeUpdate();
		} catch (SQLException e) {
			throw new UserException("Problem in inserting record" +e.getMessage());
			
		}
		
		return ct;
	}
		
	}



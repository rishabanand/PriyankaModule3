package com.cg.jsp.dao;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.jsp.exceptions.BillException;

public class DBUtil {
	private static Connection conn;
	
	public static Connection getConnection() throws BillException
	{
		if(conn==null)
		{
			try {
				InitialContext ic= new InitialContext();
				DataSource ds=(DataSource)ic.lookup("java:/OracleDS");
				conn=ds.getConnection();
			} catch (NamingException e) {
				throw new BillException("Problem in obtaining data");
				
			} catch (SQLException e) {
				throw new BillException("Problem in obtaining connection");
				
			}
					
		}
		
		return conn;
	}
	

}

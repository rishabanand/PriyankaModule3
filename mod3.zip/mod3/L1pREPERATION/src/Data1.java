
public class Data1 {

	public static void main(String[] args) {
		String str="Hello";
		str.concat("world");
		System.out.println(str);
		StringBuilder sb=new StringBuilder("abc");
		sb.append("def");
		System.out.println(sb);
	}
}

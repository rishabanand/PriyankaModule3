package com.cg.jsp.service;

import java.util.List;

import com.cg.jsp.dao.BillDao;
import com.cg.jsp.dao.BillDaoImpl;
import com.cg.jsp.dto.Bill;
import com.cg.jsp.dto.Consumers;
import com.cg.jsp.exceptions.BillException;

public class BillServiceImpl implements BillService{
	
	BillDao bdao=new BillDaoImpl();

	public BillServiceImpl() {
		
	}

	@Override
	public List<Consumers> getAllConsumers() throws BillException {
		
		return bdao.getAllConsumers();
	}

	@Override
	public Consumers getConsumers(int cid) throws BillException {
		
		return bdao.getDetails(cid);
	}

	@Override
	public List<Bill> getAllDetails(int bid) throws BillException{
		
		return bdao.getAllDetails(bid);
	}

	@Override
	public int addBillDetails(Bill bill) throws BillException {
		return bdao.addBillDetails(bill);
		
	}

	

	
	
	

	

	
}

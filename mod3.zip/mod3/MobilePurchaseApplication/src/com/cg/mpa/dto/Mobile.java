package com.cg.mpa.dto;

public class Mobile {
	private int mobileid;
	private String mobileName;
	private double price;
	private int quantity;

	public Mobile(int mobileid, String mobileName, double price, int quantity) {
		super();
		this.mobileid = mobileid;
		this.mobileName = mobileName;
		this.price = price;
		this.quantity = quantity;
	}

	public int getMobileid() {
		return mobileid;
	}

	public void setMobileid(int mobileid) {
		this.mobileid = mobileid;
	}

	public String getMobileName() {
		return mobileName;
	}

	public void setMobileName(String mobileName) {
		this.mobileName = mobileName;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public Mobile() {
		
	}

}

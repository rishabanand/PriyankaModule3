package com.cg.dao;

import java.util.List;

import com.cg.dto.AssessmentScoreBean;
import com.cg.dto.TraineeBean;
import com.cg.exceptions.ModuleException;

public interface ModuleDao {
	
	List<TraineeBean> getAllConsumers() throws ModuleException;
    public long insertAssessment(AssessmentScoreBean assg) throws ModuleException;
    public int count(int id,String Name) throws ModuleException;
}

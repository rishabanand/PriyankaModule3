package com.cg.exception;

public class ScoreException extends Exception {

	public ScoreException() {
		// TODO Auto-generated constructor stub
	}

	public ScoreException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ScoreException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public ScoreException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public ScoreException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}

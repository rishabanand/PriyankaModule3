package com.cg.demo;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;

import javax.annotation.Resource;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;


@WebServlet("/search")
public class SearchServlet extends HttpServlet {
	@Resource(lookup="java:/OracleDS")
	DataSource ds;
	private static final long serialVersionUID = 1L;
       
    
    public SearchServlet() {
        super();
       
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String empnoStr=request.getParameter("empno");
		int empno=Integer.parseInt(empnoStr);
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		try {
			//InitialContext ic= new InitialContext();
			//DataSource ds=(DataSource) ic.lookup("java:/OracleDS");
			Connection conn=ds.getConnection();
			String sql="SELECT ename,deptno,sal FROM emp where empno=?";
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1,empno);
			ResultSet rst=pst.executeQuery();
			
			if(rst.next())
			{
				out.print(rst.getString("ename"));
				out.print(rst.getDouble("sal"));
				out.print(rst.getInt("deptno"));
			}
			else
				out.print("<h2 style='color:red'> Invalid empno </h2>");
		} catch (SQLException e) {
			e.printStackTrace();
			
		}
	}

}

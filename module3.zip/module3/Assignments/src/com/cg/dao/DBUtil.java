package com.cg.dao;

import java.sql.Connection;

import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.exception.UserException;


public class DBUtil {
	static Connection conn;
	public static Connection getConnection() throws UserException
	{
		if(conn==null)
		{
			try {
				InitialContext ic=new InitialContext();
				DataSource ds=(DataSource) ic.lookup("java:/OracleDS");
				conn=ds.getConnection();
			} catch (NamingException e) {
				throw new UserException("Problem is obtaining datasource"+e.getMessage());
				
			} catch (SQLException e) {
				
				throw new UserException("Problem is obtaining Connection"+e.getMessage());
			}
			
			
		}
		return conn;
	}
	

}

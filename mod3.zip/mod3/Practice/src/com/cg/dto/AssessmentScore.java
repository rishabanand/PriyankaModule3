package com.cg.dto;

public class AssessmentScore {
	private int traineeId;
	private String moduleName;
	private int mpt;
	private int mtt;
	private int assMarks;
	private int total;
	private int grade;

	public int getTraineeId() {
		return traineeId;
	}

	public void setTraineeId(int traineeId) {
		this.traineeId = traineeId;
	}

	public String getModuleName() {
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	public int getMpt() {
		return mpt;
	}

	public void setMpt(int mpt) {
		this.mpt = mpt;
	}

	public int getMtt() {
		return mtt;
	}

	public void setMtt(int mtt) {
		this.mtt = mtt;
	}

	public int getAssMarks() {
		return assMarks;
	}

	public void setAssMarks(int assMarks) {
		this.assMarks = assMarks;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public int getGrade() {
		return grade;
	}

	public void setGrade(int grade) {
		this.grade = grade;
	}

	public AssessmentScore() {
		
	}

}

package com.cg.service;

import java.util.List;

import com.cg.dao.ModuleDao;
import com.cg.dao.ModuleDaoImpl;
import com.cg.dto.AssessmentScoreBean;
import com.cg.dto.TraineeBean;
import com.cg.exceptions.ModuleException;

public class ModuleServiceImpl implements ModuleService{
	ModuleDao mdao=new ModuleDaoImpl();

	@Override
	public List<TraineeBean> getAllConsumers() throws ModuleException {
		
		return mdao.getAllConsumers();
	}

	@Override
	public long insertAssessment(AssessmentScoreBean assg)
			throws ModuleException {
		return mdao.insertAssessment(assg);
		
	}

	@Override
	public int count(int id, String Name) throws ModuleException {
		
		return mdao.count(id, Name);
	}

	

	
}

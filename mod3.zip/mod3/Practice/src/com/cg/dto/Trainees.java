package com.cg.dto;

public class Trainees {
	private int traineeId;
	private String traineeName;

	public int getTraineeId() {
		return traineeId;
	}

	public void setTraineeId(int traineeId) {
		this.traineeId = traineeId;
	}

	public String getTraineeName() {
		return traineeName;
	}

	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}

	public Trainees() {
		
	}

	@Override
	public String toString() {
		return "Trainees [traineeId=" + traineeId + ", traineeName="
				+ traineeName + "]";
	}
	
}

package com.cg.mpa.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;







import com.cg.mpa.dto.Mobile;
import com.cg.mpa.dto.PurchaseDetails;
import com.cg.mpa.exceptions.MobileException;

public class CopyOfMobilePurchaseDaoImpl implements MobilePurchaseDao {

	Connection conn;

	@Override
	public List<Mobile> getAllMobiles() throws MobileException {
		List<Mobile> mlist = new ArrayList<>();
		conn=DBUtil.getConnection();
		String sql="SELECT mobileid,name,price,quantity FROM mobiles";
		try {
			PreparedStatement pst=conn.prepareStatement(sql);
			ResultSet rst=pst.executeQuery();
			while(rst.next())
			{
				Mobile m= new Mobile();
				m.setMobileid(rst.getInt("mobileid"));
				m.setMobileName(rst.getString("name"));
				m.setPrice(rst.getDouble("price"));
				m.setQuantity(rst.getInt("quantity"));
				mlist.add(m);
			}
		} catch (SQLException e) {
			throw new MobileException("Problem in fetching mobile list");
			
		}
		
		
		return mlist;
	}
	
	private int fetchPurchaseid() throws MobileException
	{
	 String sql="SELECT seq_purchase_id.nextval from dual";
	 conn=DBUtil.getConnection();
	 try {
		Statement st=conn.createStatement();
		 ResultSet rst=st.executeQuery(sql);
		 rst.next();
		 return rst.getInt(1);
	} catch (SQLException e) {
		throw new MobileException("Problem in generating PurchaseId");
		
	}
	}

	@Override
	public int insertPurchaseDetail(PurchaseDetails pDetails)
			throws MobileException {
		String sql="Insert INTO purchasedetails VALUES(?,?,?,?,?,?)";
		pDetails.setPurchaseid(fetchPurchaseid());
		conn=DBUtil.getConnection();
		try {
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1,pDetails.getPurchaseid());
			pst.setString(2,pDetails.getCustName());
			pst.setString(3,pDetails.getMailid());
			pst.setString(4,pDetails.getPhoneno());
			pst.setDate(5,Date.valueOf(pDetails.getPurchaseDate()));
			pst.setInt(6,pDetails.getMobileid());
		} catch (SQLException e) {
			throw new MobileException("Problem in Inserting Records");
			
		}
		
		return pDetails.getPurchaseid();
	}

	@Override
	public Mobile getMobile(int mid) throws MobileException {
		String sql="SELECT mobileid,name,price,quantity FROM mobiles WHERE mobileid=?";
		Mobile mobile=null;
		conn=DBUtil.getConnection();
		try {
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1,mid);
			ResultSet rst=pst.executeQuery();
			if(rst.next())
			{
				mobile=new Mobile();
				mobile.setMobileid(rst.getInt("mobileid"));
				mobile.setMobileName(rst.getString("name"));
				mobile.setPrice(rst.getDouble("price"));
				mobile.setQuantity(rst.getInt("quantity"));
			}
		} catch (SQLException e) {
			throw new MobileException("Problem in fetching mobile data");
		}
		return mobile;
	}

	@Override
	public int updateMobileQuantity(int mid) throws MobileException {
		
		return 0;
	}

}

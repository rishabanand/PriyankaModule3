package com.cg.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dto.Trainees;
import com.cg.exception.ScoreException;
import com.cg.service.IService;
import com.cg.service.ServiceImpl;



@WebServlet(urlPatterns={"/addassesment"})
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public Controller() {
        super();
       
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IService service=new ServiceImpl();
		String target="";
		String url=request.getServletPath();
		switch(url)
		{
		case "/addassesment":
			
			try {
				List<Trainees> tlist = service.getAllTrainees();
				request.setAttribute("tlist",tlist);
				for(Trainees t:tlist)
					System.out.println(t.getTraineeId());
				target="AddAssessment.jsp";
				
			} catch (ScoreException e) {
				System.out.println("in catch");
				String error=e.getMessage();
				request.setAttribute("error",error);
				target="Error.jsp";
				
				
			}
			
		break;
		}
		RequestDispatcher disp=request.getRequestDispatcher(target);
		disp.forward(request,response);
		
	}

}

package com.cg.date;

public class Class {

	public static void main(String[] args) {
	 int num=456;
	System.out.println(num++);
	String str1="Hello";
	String str2="hello";
	//if(str1.equals(str2))
		if(str1==str2)
	{
		System.out.println("equals");
	}
	else
		System.out.println("not equals");
			
	}

}

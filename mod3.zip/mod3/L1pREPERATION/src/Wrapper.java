
public class Wrapper {

	public static void main(String[] args) {
			String str1=new String("Hello");
			String str2="Hello";
			if(str1==str2)
			{
				System.out.println("equal");
			}
			else
			{
				System.out.println("not");
			}
		}	
}

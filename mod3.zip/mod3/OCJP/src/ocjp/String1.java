package ocjp;


	public class String1 {
		public static void main(String[] args) { 
			int b = 3;
			if ( !(b > 3)) {
			System.out.println("square ");
			}
			{
			System.out.println("circle ");
			}
		}
}
package com.cg.service;

import com.cg.dto.Employee;
import com.cg.exceptions.EmpException;

public interface EmpService {
	int registerEmp(Employee emp) throws EmpException;

}

package com.cg.demo;


public class App 
{
    public static void main( String[] args )
    {
	    System.out.println("Hello");
        System.out.println( "Hello World!" );
    }
	public String Sayhello()
	{
	return "Vaishali";
    }
}



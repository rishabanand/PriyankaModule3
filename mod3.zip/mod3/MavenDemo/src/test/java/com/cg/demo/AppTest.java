package com.cg.demo;
import org.junit.Test;
import org.junit.*;
import static org.junit.Assert.assertEquals;
import org.junit.BeforeClass;

public class AppTest 
{
   
	static App app=null;
	  @BeforeClass
		public static void beforeClass()
		{
		 app=new App();
		System.out.println("In Before Class");
         }
       @Test
	   public void testSayHello()
	   {
	   assertEquals("Vaishali",app.Sayhello());

       }
       }
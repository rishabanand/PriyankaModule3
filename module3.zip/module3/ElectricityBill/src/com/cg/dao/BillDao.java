package com.cg.dao;

import java.util.function.Consumer;

import com.cg.dto.BillDetails;
import com.cg.dto.Customer;
import com.cg.exception.BillException;

public interface BillDao {
	
int addBillDetails(BillDetails bill) throws BillException;

Customer getCustomerDetails(int cid) throws BillException;
}

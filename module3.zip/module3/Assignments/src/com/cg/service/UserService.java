package com.cg.service;

import com.cg.dto.User;
import com.cg.exception.UserException;


public interface UserService {
	int registerUser(User user) throws UserException;

}

package ocjp;


	

	public class TestOperator {
		public static void main(String[] args) { 
			int result = 30 -12 / (2*5)+1; System.out.print("Result = " + result);
		}
		}



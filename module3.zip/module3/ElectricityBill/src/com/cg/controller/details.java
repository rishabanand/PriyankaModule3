package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.function.Consumer;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dto.BillDetails;
import com.cg.dto.Customer;
import com.cg.exception.BillException;
import com.cg.service.ServiceBill;
import com.cg.service.ServiceBillImpl;


@WebServlet("/details")
public class details extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public details() {
        super();
        
    }

	public double CalculateUnitConsumed( double lastreading,double currentreading)
	{
		int fixedcharge=100;
		double unitconsumed = (lastreading-currentreading);
		double billamount =  (unitconsumed*1.15) + fixedcharge;
		return billamount;
     }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ServiceBill service=new ServiceBillImpl();
		
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		int consumerno=Integer.parseInt(request.getParameter("consno"));
		double lastreading=Double.parseDouble(request.getParameter("lmmr"));
		double currentreading=Double.parseDouble(request.getParameter("cmmr"));
		double unitconsumed=currentreading-lastreading;
		
		
		
		//service.getCustomerDetails(consumerno);
		
		String target="";
		
		
		try {
			if(currentreading>lastreading)
			{
			
				double billAmt=CalculateUnitConsumed( lastreading, currentreading);
				BillDetails bill=new BillDetails(consumerno,currentreading,unitconsumed,billAmt);
				service.addBillDetails(bill);
				request.setAttribute("bill", bill);
				Customer cust=service.getCustomerDetails(consumerno);
				HttpSession session=request.getSession(true);
				session.setAttribute("cust",cust);
				   target="success";
					
			}		
				
			
				else
				{
					throw new BillException("Current Reading is less tan that of last month");
				}
		} catch (BillException e) {
			request.setAttribute("message",e.getMessage());
		     target="error";
			
		}
		RequestDispatcher disp=request.getRequestDispatcher(target);
		disp.forward(request, response);
		
			
			
				
		}	
	

	
	
}

